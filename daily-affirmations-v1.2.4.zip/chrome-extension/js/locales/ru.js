/**
 * Russian translations
 */

export default {
    // Common
    common: {
        start: 'Старт',
        stop: 'Стоп',
        pause: 'Пауза',
        resume: 'Продолжить',
        settings: 'Настройки',
        close: 'Закрыть',
        save: 'Сохранить',
        cancel: 'Отмена',
        ok: 'ОК',
        yes: 'Да',
        no: 'Нет',
        loading: 'Загрузка...',
        error: 'Ошибка',
        success: 'Успешно',
        warning: 'Предупреждение',
        info: 'Информация',
        display: 'Отображение',
        showWeather: 'Показать погоду',
        showClock: 'Показать часы',
        returnToRandom: 'Вернуться к случайным фонам',
        randomMode: 'Случайный режим',
        fixedBackground: 'Фиксированный фон',
        randomBackgrounds: 'Случайные фоны',
        noSavedBackgrounds: 'Пока нет сохранённых фонов',
        saveFromUnsplash: 'Сохраняйте фоны из Unsplash или добавьте свои изображения',
        currentBackground: 'Текущий',
        lastUsed: 'Последний использованный',
        useThisBackground: 'Использовать этот фон',
        setAsFixedBackground: 'Установить как фиксированный фон',
        removeFromSaved: 'Удалить из сохранённых фонов',
        customBackground: 'Пользовательский фон',
        switching: 'Переключение...',
        uploading: 'Загрузка...',
        noAffirmationsInCollection: 'В этой коллекции пока нет аффирмаций.',
        removeFromSaved: 'Удалить из сохранённых',
        error: 'Ошибка',
        failedToPerformAction: 'Не удалось выполнить действие'
    },

    // Breathing exercise
    breathing: {
        title: 'Дыхательное упражнение',
        ready: 'Готовы дышать',
        clickStart: 'Нажмите старт для начала',
        pattern: 'Паттерн дыхания',
        duration: 'Длительность',
        minutes: 'минут',
        sessionComplete: 'Сессия завершена!',
        sessionCompleteMessage: 'Отлично! Вы завершили дыхательное упражнение.',
        completeMessage: '✓ Завершено',
        wellDoneMessage: 'Отлично! Позвольте себе оценить вашу концентрацию.',
        
        // Phases
        phases: {
            inhale: 'Вдох',
            hold: 'Задержка',
            exhale: 'Выдох',
            hold_after_exhale: 'Пауза'
        },
        
        // Instructions
        instructions: {
            inhale: 'Медленно вдыхайте через нос',
            hold: 'Задержите дыхание',
            exhale: 'Медленно выдыхайте через рот',
            hold_after_exhale: 'Отдохните перед следующим вдохом',
            followCircle: 'Следуйте за кругом'
        },
        
        // Patterns
        patterns: {
            box: 'Квадратное дыхание',
            '4-7-8': 'Дыхание 4-7-8',
            triangle: 'Треугольное дыхание',
            relaxing: 'Расслабляющее дыхание',
            energizing: 'Энергизирующее дыхание',
            mindful: 'Осознанное дыхание'
        },
        
        // Pattern descriptions
        patternDescriptions: {
            box: 'Сбалансированная техника дыхания, используемая морскими котиками для управления стрессом и концентрации.',
            '4-7-8': 'Успокаивающая техника, которая помогает снизить тревожность и способствует расслаблению.',
            triangle: 'Простой, сбалансированный паттерн дыхания, идеальный для начинающих.',
            relaxing: 'Мягкий паттерн, предназначенный для глубокого расслабления и снятия стресса.',
            energizing: 'Быстрый, энергизирующий паттерн для повышения бдительности и энергии.',
            mindful: 'Простой паттерн, сосредоточенный на осознанности и присутствии в моменте.'
        },
        
        // Benefits
        benefits: {
            box: ['Снижает стресс', 'Улучшает концентрацию', 'Балансирует нервную систему'],
            '4-7-8': ['Снижает тревожность', 'Способствует сну', 'Успокаивает нервную систему'],
            triangle: ['Легко изучить', 'Способствует спокойствию', 'Подходит для начинающих'],
            relaxing: ['Глубокое расслабление', 'Снятие стресса', 'Лучший сон'],
            energizing: ['Повышает энергию', 'Улучшает бдительность', 'Быстрая активация'],
            mindful: ['Осознанность', 'Осознание настоящего момента', 'Ментальная ясность']
        },
        
        // Settings
        settings: {
            title: 'Настройки дыхания',
            defaultPattern: 'Паттерн по умолчанию',
            defaultDuration: 'Длительность по умолчанию',
            autoStart: 'Автозапуск на новой вкладке',
            sound: 'Звук',
            analytics: 'Показать аналитику',
            theme: 'Тема дыхания',
            comingSoon: 'Панель настроек скоро появится!',
            patternChanged: 'Паттерн дыхания изменён',
            durationChanged: 'Длительность дыхания изменена',
            startNewSession: 'Начать новую сессию'
        },
        
        // Statistics
        stats: {
            totalSessions: 'Всего сессий',
            totalTime: 'Общее время',
            currentStreak: 'Текущая серия',
            longestStreak: 'Самая длинная серия',
            averageSession: 'Средняя сессия',
            thisWeek: 'На этой неделе',
            thisMonth: 'В этом месяце'
        },
        
        // Reports
        reports: {
            title: 'Отчеты дыхания',
            phase: 'Фаза',
            duration: 'Длительность',
            timestamp: 'Время'
        }
    },

    // Main app
    app: {
        title: 'Новая вкладка',
        weather: 'Погода',
        affirmations: 'Аффирмации',
        breathing: 'Дыхание',
        settings: 'Настройки',
        premium: 'Премиум',
        backup: 'Резервная копия',
        restore: 'Восстановление'
    },

    // Weather
    weather: {
        loading: 'Загрузка погоды...',
        error: 'Не удалось загрузить погоду',
        noData: 'Данные о погоде недоступны',
        feelsLike: 'Ощущается как',
        humidity: 'Влажность',
        wind: 'Ветер',
        pressure: 'Давление',
        visibility: 'Видимость',
        uvIndex: 'УФ-индекс'
    },

    // Affirmations
    affirmations: {
        loading: 'Загрузка аффирмаций...',
        error: 'Не удалось загрузить аффирмации',
        noData: 'Аффирмации недоступны',
        refresh: 'Обновить',
        favorite: 'В избранное',
        share: 'Поделиться',
        copy: 'Копировать',
        new: 'Новая аффирмация',
        addToFavorites: 'Добавить в избранное',
        manageFavorites: 'Управление избранным'
    },

    // Settings
    settings: {
        title: 'Настройки',
        theme: 'Тема',
        language: 'Язык',
        notifications: 'Уведомления',
        privacy: 'Конфиденциальность',
        about: 'О программе',
        version: 'Версия',
        developer: 'Разработчик',
        backgroundTheme: 'Тема фона',
        cardStyle: 'Стиль карточек',
        fontStyle: 'Стиль шрифта',
        textColor: 'Цвет текста',
        backup: 'Резервная копия',
        resetToDefaults: 'Сбросить настройки',
        sections: {
            language: 'Язык',
            display: 'Отображение',
            theme: 'Тема',
            breathingExercise: 'Дыхательное упражнение',
            helpShortcuts: 'Справка и ярлыки'
        },
        labels: {
            language: 'Язык',
            showWeather: 'Показать погоду',
            showClock: 'Показать часы',
            showTodaysFocus: 'Показать Фокус сегодня',
            backgroundTheme: 'Тема фона',
            cardStyle: 'Стиль карточек',
            fontStyle: 'Стиль шрифта',
            textColor: 'Цвет текста',
            defaultPattern: 'Паттерн по умолчанию',
            defaultDuration: 'Длительность по умолчанию',
            autoStartNewTab: 'Автозапуск на новой вкладке',
            breathingTheme: 'Тема дыхания',
            keyboardShortcuts: 'Горячие клавиши',
            helpFaq: 'Справка и FAQ'
        },
        values: {
            nature: 'Природа',
            minimal: 'Минимализм',
            architecture: 'Архитектура',
            abstract: 'Абстрактное',
            glass: 'Стекло',
            solid: 'Сплошной',
            default: 'По умолчанию',
            serif: 'С засечками',
            monospace: 'Моноширинный',
            box: 'Квадратное дыхание',
            '4-7-8': 'Дыхание 4-7-8',
            triangle: 'Треугольное дыхание',
            relaxing: 'Расслабляющее дыхание',
            energizing: 'Энергизирующее дыхание',
            mindful: 'Осознанное дыхание',
            calm: 'Спокойное',
            energizingTheme: 'Энергичное',
            oneMinute: '1 минута',
            threeMinutes: '3 минуты',
            fiveMinutes: '5 минут',
            tenMinutes: '10 минут',
            fifteenMinutes: '15 минут'
        }
    },

    // Premium
    premium: {
        title: 'Премиум функции',
        upgrade: 'Обновить до Премиум',
        features: 'Премиум функции',
        trial: 'Пробный период',
        subscribe: 'Подписаться',
        manage: 'Управление подпиской',
        free: 'Бесплатно'
    },

    // Keyboard shortcuts
    shortcuts: {
        breathing: 'Начать дыхательное упражнение',
        weather: 'Обновить погоду',
        affirmations: 'Обновить аффирмации',
        settings: 'Открыть настройки',
        title: 'Горячие клавиши',
        space: 'Получить новую аффирмацию',
        newAffirmation: 'Получить новую аффирмацию',
        openSettings: 'Открыть настройки',
        openMenu: 'Открыть меню',
        startBreathing: 'Начать дыхательное упражнение',
        openTaskManager: 'Открыть менеджер задач',
        toggleFocus: 'Переключить режим фокуса',
        copyAffirmation: 'Копировать аффирмацию',
        closeDialogs: 'Закрыть диалоги',
        tip: 'Горячие клавиши отключены при наборе текста'
    },
    
    // Today's Focus
    todaysFocus: {
        title: 'Фокус сегодня',
        showLabel: 'Показать фокус сегодня',
        emptyMessage: 'Сосредоточьтесь на приоритетах',
        viewAll: 'Посмотреть все задачи'
    },

    // Time formats
    time: {
        now: 'сейчас',
        minutesAgo: '{{count}} мин назад',
        hoursAgo: '{{count}} ч назад',
        daysAgo: '{{count}} дн назад',
        weeksAgo: '{{count}} нед назад',
        monthsAgo: '{{count}} мес назад',
        yearsAgo: '{{count}} г назад'
    },

    // Errors
    errors: {
        network: 'Ошибка сети',
        permission: 'Недостаточно прав',
        storage: 'Ошибка хранилища',
        unknown: 'Неизвестная ошибка',
        retry: 'Повторить попытку'
    },

    // Notifications
    notifications: {
        themeUpdated: 'Тема обновлена',
        themeChanged: 'Тема фона изменена на {{theme}}',
        settingsUpdated: 'Настройки обновлены',
        premiumRequired: 'Требуется Премиум',
        error: 'Ошибка',
        upgradeToPro: 'Обновитесь до Pro для использования этой функции',
        backgroundSaved: 'Фон сохранён',
        affirmationCopied: 'Аффирмация скопирована в буфер обмена',
        favoritesAdded: 'Добавлено в избранное',
        favoritesRemoved: 'Удалено из избранного',
        patternChanged: 'Паттерн дыхания изменён',
        durationChanged: 'Длительность дыхания изменена',
        affirmationAdded: 'Аффирмация добавлена',
        affirmationSaved: 'Ваша аффирмация сохранена',
        affirmationDeleted: 'Аффирмация удалена',
        affirmationSet: 'Ваша пользовательская аффирмация отображается'
    },

    // Dialogs
    dialogs: {
        customAffirmations: 'Пользовательские аффирмации',
        savedBackgrounds: 'Сохранённые фоны',
        addCustomBackground: 'Добавить пользовательский фон',
        breathingExercise: 'Дыхательное упражнение',
        backupAndSync: 'Резервное копирование и синхронизация',
        cloudSyncStatus: 'Статус облачной синхронизации',
        cloudSyncDescription: 'Ваши данные синхронизируются на всех устройствах через Chrome Sync',
        localBackup: 'Локальная резервная копия',
        localBackupDescription: 'Создать резервную копию ваших настроек, избранного и пользовательских аффирмаций',
        downloadBackup: 'Скачать резервную копию',
        restoreFromBackup: 'Восстановить из резервной копии',
        autoBackup: 'Автоматическое резервное копирование',
        autoBackupDescription: 'Ваши данные автоматически сохраняются каждый день',
        lastBackupCompleted: 'Последнее резервное копирование завершено успешно',
        lastBackup: 'Последнее резервное копирование',
        collections: {
            personal: 'Личное',
            motivation: 'Мотивация',
            gratitude: 'Благодарность',
            success: 'Успех'
        },
        tabs: {
            personal: 'Личное',
            motivation: 'Мотивация',
            gratitude: 'Благодарность',
            success: 'Успех'
        },
        useAffirmation: 'Использовать эту аффирмацию',
        deleteAffirmation: 'Удалить аффирмацию',
        typeYourAffirmation: 'Введите свою аффирмацию...',
        add: 'Добавить'
    },

    // Premium Modal
    premiumModal: {
        title: 'Разблокировать Pro функции',
        favoriteAffirmationsTitle: 'Избранные аффирмации',
        favoriteAffirmationsDesc: 'Сохраняйте избранные аффирмации',
        shareTitle: 'Поделиться аффирмациями',
        shareDesc: 'Поделитесь избранными аффирмациями',
        customAffirmationsTitle: 'Пользовательские аффирмации',
        customAffirmationsDesc: 'Создавайте и управляйте своими аффирмациями',
        dailyRemindersTitle: 'Ежедневные напоминания',
        dailyRemindersDesc: 'Получайте уведомления в удобное время',
        pricing: 'Цены',
        monthly: 'Ежемесячно',
        pricePerMonth: '/месяц',
        chooseMonthly: 'Выбрать ежемесячно',
        yearly: 'Годовой',
        pricePerYear: '/год',
        bestValue: 'Лучшая цена',
        save: 'Экономия 33%',
        allProFeatures: 'Все Pro функции',
        prioritySupport: 'Приоритетная поддержка',
        cancelAnytime: 'Отменить в любое время',
        twoMonthsFree: '2 месяца бесплатно',
        chooseYearly: 'Выбрать годовой',
        notSureYet: 'Не уверены? Попробуйте Pro бесплатно 7 дней',
        startFreeTrial: 'Начать бесплатную пробную версию',
        closeModal: 'Закрыть окно'
    },

    // Help Dialog
    help: {
        title: 'Помощь',
        gettingStarted: 'Начало работы',
        gettingStartedDesc: 'Новые аффирмации появляются каждый раз при открытии новой вкладки. Нажмите кнопку обновления, чтобы увидеть новую.',
        favorites: 'Избранное',
        favoritesDesc: 'Нажмите на сердечко, чтобы сохранить понравившиеся аффирмации. Получите доступ к ним в любое время из меню.',
        customAffirmations: 'Пользовательские аффирмации',
        customAffirmationsDesc: 'Создавайте и управляйте своими аффирмациями в разделе «Пользовательские аффирмации».'
    },

    // Feedback Dialog
    feedback: {
        title: 'Отправить отзыв',
        intro: 'Мы будем рады услышать от вас!',
        description: 'Ваш отзыв помогает нам улучшать Daily Affirmations для всех.',
        selectFeedbackType: 'Выбрать тип отзыва',
        suggestion: 'Предложение',
        bugReport: 'Сообщить об ошибке',
        other: 'Другое',
        yourEmail: 'Ваш email (необязательно)',
        tellUs: 'Расскажите нам, что вы думаете...',
        keepMeUpdated: 'Следить за обновлениями',
        sendFeedback: 'Отправить отзыв',
        sending: 'Отправка...',
        thankYou: 'Спасибо!',
        thankYouDesc: 'Ваш отзыв получен. Мы ценим ваш вклад!',
        error: 'Ошибка',
        errorDesc: 'Не удалось отправить отзыв. Попробуйте снова.'
    },

    // About Dialog
    about: {
        title: 'О Daily Affirmations',
        version: 'Версия',
        description: 'Измените образ мышления с помощью ежедневных позитивных аффирмаций.',
        dailyCuratedAffirmations: 'Ежедневные курируемые аффирмации',
        saveFavorites: 'Сохраняйте избранное',
        createCustom: 'Создавайте пользовательские аффирмации',
        cloudBackup: 'Облачное резервное копирование и синхронизация',
        privacyPolicy: 'Политика конфиденциальности',
        termsOfService: 'Условия использования',
        copyright: '© 2024 Daily Affirmations. Все права защищены.',
        separator: '•'
    },

    // Menu
    menu: {
        myCollections: 'Мои коллекции',
        favoriteAffirmations: 'Избранные аффирмации',
        customAffirmations: 'Пользовательские аффирмации',
        savedBackgrounds: 'Сохранённые фоны',
        dailyReminders: 'Ежедневные напоминания',
        themeSettings: 'Настройки темы',
        backup: 'Резервное копирование и синхронизация',
        help: 'Помощь',
        feedback: 'Обратная связь',
        about: 'О программе'
    },

    // Accessibility
    accessibility: {
        openSettings: 'Открыть панель настроек',
        openMenu: 'Открыть главное меню',
        toggleFocus: 'Переключить режим фокуса',
        startBreathing: 'Начать дыхательное упражнение',
        weatherInfo: 'Информация о погоде',
        skipToContent: 'Перейти к основному содержимому',
        closeDialog: 'Закрыть диалог'
    },

    // Reminders
    reminders: {
        title: 'Ежедневные напоминания',
        enable: 'Включить ежедневные напоминания',
        testNotification: 'Тестовое уведомление',
        repeatOn: 'Повторять в',
        reminderTimes: 'Время напоминаний',
        addTime: 'Добавить время',
        customMessage: 'Пользовательское сообщение',
        customMessagePlaceholder: 'Время для вашей ежедневной аффирмации!',
        mon: 'Пн',
        tue: 'Вт',
        wed: 'Ср',
        thu: 'Чт',
        fri: 'Пт',
        sat: 'Сб',
        sun: 'Вс',
        blockedInSettings: 'Уведомления заблокированы в системных настройках. Пожалуйста, включите их для получения ежедневных аффирмаций.',
        openSystemSettings: 'Открыть системные настройки',
        notSupported: 'Уведомления не поддерживаются в этом браузере',
        needsPermission: 'Расширению Chrome требуется разрешение на уведомления',
        enableInSettings: 'Пожалуйста, включите уведомления в системных настройках',
        testNotificationTitle: 'Тестовое уведомление',
        testNotificationMessage: 'Уведомления работают! Обновитесь до Pro для получения ежедневных напоминаний об аффирмациях 🎉',
        testNotificationSent: 'Тестовое уведомление отправлено! Проверьте центр уведомлений.',
        settingsSaved: 'Настройки сохранены',
        settingsUpdated: 'Настройки напоминаний обновлены',
        settingsSavedFailed: 'Не удалось сохранить настройки напоминаний'
    },
    
    // TODO / Менеджер задач
    todo: {
        widget: {
            title: 'Менеджер задач (T)',
            ariaLabel: 'Менеджер задач',
            noTasks: 'Нет активных задач',
            activeTasks: '{{count}} активных задач',
            overdue: 'просрочено'
        },
        manager: {
            title: 'Менеджер задач',
            addTask: 'Добавить задачу',
            searchTasks: 'Поиск задач...',
            allTasks: 'Все',
            activeTasks: 'Активные',
            completedTasks: 'Завершенные',
            dueToday: 'Срок сегодня',
            noTasks: 'Пока нет задач. Создайте первую задачу!',
            editTask: 'Редактировать задачу',
            deleteTask: 'Удалить задачу',
            completeTask: 'Завершить задачу',
            uncompleteTask: 'Снять завершение'
        },
        priorities: {
            urgent: 'Срочно',
            high: 'Высокий',
            normal: 'Обычный',
            low: 'Низкий'
        },
        categories: {
            work: 'Работа',
            personal: 'Личное',
            health: 'Здоровье',
            learning: 'Обучение',
            shopping: 'Покупки',
            other: 'Другое'
        },
        addTask: {
            title: 'Добавить новую задачу',
            taskTitle: 'Название',
            taskTitlePlaceholder: 'Введите название задачи',
            taskDescription: 'Описание',
            taskDescriptionPlaceholder: 'Введите описание задачи',
            taskPriority: 'Приоритет',
            taskCategory: 'Категория',
            taskDueDate: 'Срок',
            taskTags: 'Теги',
            taskTagsPlaceholder: 'тег1, тег2, тег3',
            saveTask: 'Сохранить задачу',
            cancel: 'Отмена',
            titleRequired: 'Название задачи обязательно',
            taskAdded: 'Задача добавлена успешно',
            taskLimitExceeded: 'Бесплатная версия ограничена 10 активными задачами',
            taskUpdated: 'Задача обновлена успешно',
            taskDeleted: 'Задача удалена успешно',
            taskCompleted: 'Задача завершена!',
            uncompleteTask: 'Завершение задачи снято'
        },
        pomodoro: {
            title: 'Помодоро таймер',
            focusTime: 'Время фокуса',
            breakTime: 'Перерыв',
            start: 'Старт',
            pause: 'Пауза',
            resume: 'Возобновить',
            reset: 'Сброс',
            skip: 'Пропустить',
            workingOn: 'Работаю над:',
            selectTask: 'Выберите задачу...',
            focusDuration: 'Длительность фокуса (минуты)',
            breakDuration: 'Длительность перерыва (минуты)',
            completed: 'Завершено',
            minutesToday: 'Минут сегодня',
            pomodoroComplete: 'Помодоро завершен!',
            takeBreak: 'Хорошо заслуженный перерыв',
            breakOver: 'Перерыв окончен',
            timeToFocus: 'Время сфокусироваться!',
            sessionComplete: 'Отличная работа! Вы завершили сессию Помодоро.'
        },
        dashboard: {
            title: 'Панель продуктивности',
            completedTasks: 'Завершенные задачи',
            activeTasks: 'Активные задачи',
            completionRate: 'Процент выполнения',
            pomodoroSessions: 'Сессии Помодоро',
            tasksByPriority: 'Задачи по приоритету',
            tasksByCategory: 'Задачи по категориям',
            recentActivity: 'Недавняя активность',
            noRecentActivity: 'Нет недавней активности',
            dailyCompletion: 'Ежедневное выполнение (последние 7 дней)',
            productivityInsights: 'Инсайты продуктивности',
            excellentProductivity: 'Отличная продуктивность! Вы выполняете задачи с высокой скоростью.',
            goodProgress: 'Хороший прогресс! Продолжайте в том же духе.',
            increaseRate: 'Попробуйте увеличить процент выполнения, сосредоточившись на одной задаче за раз.',
            overdueTask: 'У вас {{count}} просроченная задача. Рассмотрите возможность корректировки сроков.',
            overdueTasks: 'У вас {{count}} просроченных задач. Рассмотрите возможность корректировки сроков.',
            allDone: 'Все готово! Отличная работа по завершению всех ваших задач. Так держать!',
            manyActive: 'У вас много активных задач. Рассмотрите возможность разбивки на более мелкие подзадачи.',
            mostTasksCategory: 'Большинство ваших задач в категории "{{category}}". Рассмотрите возможность разнообразия фокуса.',
            noInsights: 'Инсайтов пока нет. Выполните несколько задач, чтобы увидеть персонализированные инсайты!'
        },
        stats: {
            total: 'Всего',
            active: 'Активные',
            completed: 'Завершенные',
            dueToday: 'Срок сегодня',
            overdue: 'Просрочено'
        },
        errors: {
            taskNotFound: 'Задача не найдена',
            failedToAdd: 'Не удалось добавить задачу',
            failedToUpdate: 'Не удалось обновить задачу',
            failedToDelete: 'Не удалось удалить задачу',
            failedToComplete: 'Не удалось завершить задачу',
            taskManagerFailed: 'Не удалось открыть менеджер задач',
            networkError: 'Ошибка сети',
            storageError: 'Ошибка хранилища'
        }
    }
};
