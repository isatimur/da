/**
 * Arabic translations
 */

export default {
    // Common
    common: {
        start: 'ابدأ',
        stop: 'إيقاف',
        pause: 'إيقاف مؤقت',
        resume: 'استئناف',
        settings: 'الإعدادات',
        close: 'إغلاق',
        save: 'حفظ',
        cancel: 'إلغاء',
        ok: 'حسناً',
        yes: 'نعم',
        no: 'لا',
        loading: 'جاري التحميل...',
        error: 'خطأ',
        success: 'نجاح',
        warning: 'تحذير',
        info: 'معلومات',
        display: 'العرض',
        showWeather: 'إظهار الطقس',
        showClock: 'إظهار الساعة',
        returnToRandom: 'العودة إلى الخلفيات العشوائية',
        randomMode: 'الوضع العشوائي',
        fixedBackground: 'خلفية ثابتة',
        randomBackgrounds: 'خلفيات عشوائية',
        noSavedBackgrounds: 'لا توجد خلفيات محفوظة بعد',
        saveFromUnsplash: 'احفظ الخلفيات من Unsplash أو أضف صورك المخصصة',
        currentBackground: 'الحالي',
        lastUsed: 'أخر استخدام',
        useThisBackground: 'استخدم هذه الخلفية',
        setAsFixedBackground: 'تعيين كخلفية ثابتة',
        removeFromSaved: 'إزالة من الخلفيات المحفوظة',
        customBackground: 'خلفية مخصصة',
        switching: 'جاري التحويل...',
        uploading: 'جاري الرفع...',
        noAffirmationsInCollection: 'لا توجد توكيدات في هذه المجموعة بعد.',
        removeFromSaved: 'إزالة من المحفوظة',
        error: 'خطأ',
        failedToPerformAction: 'فشل في تنفيذ الإجراء'
    },

    // Breathing exercise
    breathing: {
        title: 'تمرين التنفس',
        ready: 'مستعد للتنفس',
        clickStart: 'انقر للبدء',
        pattern: 'نمط التنفس',
        duration: 'المدة',
        minutes: 'دقائق',
        sessionComplete: 'اكتملت الجلسة!',
        sessionCompleteMessage: 'ممتاز! لقد أكملت جلسة التنفس الخاصة بك.',
        completeMessage: '✓ اكتمل',
        wellDoneMessage: 'أحسنت! خذ لحظة لتقدير تركيزك.',
        
        // Phases
        phases: {
            inhale: 'تنفس',
            hold: 'أمسك',
            exhale: 'زفر',
            hold_after_exhale: 'استراحة'
        },
        
        // Instructions
        instructions: {
            inhale: 'تنفس ببطء من أنفك',
            hold: 'أمسك أنفاسك برفق',
            exhale: 'زفر ببطء من فمك',
            hold_after_exhale: 'استرح واحضر للتنفس التالي',
            followCircle: 'اتبع الدائرة'
        },
        
        // Patterns
        patterns: {
            box: 'تنفس الصندوق',
            '4-7-8': 'تنفس 4-7-8',
            triangle: 'تنفس المثلث',
            relaxing: 'تنفس الاسترخاء',
            energizing: 'تنفس النشاط',
            mindful: 'التنفس اليقظ'
        },
        
        // Pattern descriptions
        patternDescriptions: {
            box: 'تقنية تنفس متوازنة يستخدمها Navy SEALs لإدارة الإجهاد والتركيز.',
            '4-7-8': 'تقنية مهدئة تساعد في تقليل القلق وتعزز الاسترخاء.',
            triangle: 'نمط تنفس بسيط ومتوازن مثالي للمبتدئين.',
            relaxing: 'نمط لطيف مصمم للاسترخاء العميق وتخفيف الإجهاد.',
            energizing: 'نمط سريع ومنشط لتعزيز اليقظة والطاقة.',
            mindful: 'نمط بسيط يركز على الوعي اليقظ والوجود في اللحظة.'
        },
        
        // Benefits
        benefits: {
            box: ['يقلل الإجهاد', 'يحسن التركيز', 'يوازن الجهاز العصبي'],
            '4-7-8': ['يقلل القلق', 'يعزز النوم', 'يهدئ الجهاز العصبي'],
            triangle: ['سهل التعلم', 'يعزز الهدوء', 'جيد للمبتدئين'],
            relaxing: ['استرخاء عميق', 'تخفيف الإجهاد', 'نوم أفضل'],
            energizing: ['يزيد الطاقة', 'يحسن اليقظة', 'تفعيل سريع'],
            mindful: ['اليقظة', 'وعي اللحظة الحاضرة', 'وضوح ذهني']
        },
        
        // Settings
        settings: {
            title: 'إعدادات التنفس',
            defaultPattern: 'النمط الافتراضي',
            defaultDuration: 'المدة الافتراضية',
            autoStart: 'بدء تلقائي في علامة تبويب جديدة',
            sound: 'الصوت',
            analytics: 'إظهار التحليلات',
            theme: 'سمة التنفس',
            comingSoon: 'لوحة الإعدادات قريباً!',
            patternChanged: 'تم تغيير نمط التنفس',
            durationChanged: 'تم تغيير مدة التنفس',
            startNewSession: 'بدء جلسة جديدة'
        },
        
        // Statistics
        stats: {
            totalSessions: 'إجمالي الجلسات',
            totalTime: 'الوقت الإجمالي',
            currentStreak: 'السلسلة الحالية',
            longestStreak: 'أطول سلسلة',
            averageSession: 'متوسط الجلسة',
            thisWeek: 'هذا الأسبوع',
            thisMonth: 'هذا الشهر'
        },
        
        // Reports
        reports: {
            title: 'تقارير التنفس',
            phase: 'المرحلة',
            duration: 'المدة',
            timestamp: 'الوقت'
        }
    },

    // Main app
    app: {
        title: 'علامة تبويب جديدة',
        weather: 'الطقس',
        affirmations: 'التوكيدات',
        breathing: 'التنفس',
        settings: 'الإعدادات',
        premium: 'بريميوم',
        backup: 'النسخ الاحتياطي',
        restore: 'استعادة'
    },

    // Weather
    weather: {
        loading: 'جاري تحميل الطقس...',
        error: 'فشل تحميل الطقس',
        noData: 'بيانات الطقس غير متاحة',
        feelsLike: 'تشعر بـ',
        humidity: 'الرطوبة',
        wind: 'الرياح',
        pressure: 'الضغط',
        visibility: 'الرؤية',
        uvIndex: 'مؤشر الأشعة فوق البنفسجية'
    },

    // Affirmations
    affirmations: {
        loading: 'جاري تحميل التوكيدات...',
        error: 'فشل تحميل التوكيدات',
        noData: 'التوكيدات غير متاحة',
        refresh: 'تحديث',
        favorite: 'مفضل',
        share: 'مشاركة',
        copy: 'نسخ',
        new: 'توكيد جديد',
        addToFavorites: 'إضافة إلى المفضلة',
        manageFavorites: 'إدارة المفضلة'
    },

    // Settings
    settings: {
        title: 'الإعدادات',
        theme: 'السمة',
        language: 'اللغة',
        notifications: 'الإشعارات',
        privacy: 'الخصوصية',
        about: 'حول',
        version: 'الإصدار',
        developer: 'المطور',
        backgroundTheme: 'موضوع الخلفية',
        cardStyle: 'نمط البطاقة',
        fontStyle: 'نمط الخط',
        textColor: 'لون النص',
        backup: 'النسخ الاحتياطي',
        resetToDefaults: 'إعادة الضبط الافتراضية'
    },

    // Premium
    premium: {
        title: 'ميزات بريميوم',
        upgrade: 'الترقية إلى بريميوم',
        features: 'ميزات بريميوم',
        trial: 'فترة التجربة',
        subscribe: 'اشترك',
        manage: 'إدارة الاشتراك',
        free: 'مجاني'
    },

    // Keyboard shortcuts
    shortcuts: {
        breathing: 'بدء تمرين التنفس',
        weather: 'تحديث الطقس',
        affirmations: 'تحديث التوكيدات',
        settings: 'فتح الإعدادات'
    },

    // Time formats
    time: {
        now: 'الآن',
        minutesAgo: 'منذ {{count}} دقيقة',
        hoursAgo: 'منذ {{count}} ساعة',
        daysAgo: 'منذ {{count}} يوم',
        weeksAgo: 'منذ {{count}} أسبوع',
        monthsAgo: 'منذ {{count}} شهر',
        yearsAgo: 'منذ {{count}} سنة'
    },

    // Errors
    errors: {
        network: 'خطأ في الشبكة',
        permission: 'أذونات غير كافية',
        storage: 'خطأ في التخزين',
        unknown: 'خطأ غير معروف',
        retry: 'إعادة المحاولة'
    },

    // Notifications
    notifications: {
        themeUpdated: 'تم تحديث السمة',
        themeChanged: 'تم تغيير موضوع الخلفية إلى {{theme}}',
        settingsUpdated: 'تم تحديث الإعدادات',
        premiumRequired: 'مطلوب بريميوم',
        error: 'خطأ',
        upgradeToPro: 'قم بالترقية إلى Pro لاستخدام هذه الميزة',
        backgroundSaved: 'تم حفظ الخلفية',
        affirmationCopied: 'تم نسخ التوكيد إلى الحافظة',
        favoritesAdded: 'تمت الإضافة إلى المفضلة',
        favoritesRemoved: 'تمت إزالة من المفضلة',
        patternChanged: 'تم تغيير نمط التنفس',
        durationChanged: 'تم تغيير مدة التنفس',
        affirmationAdded: 'تمت إضافة التوكيد',
        affirmationSaved: 'تم حفظ توكيدك',
        affirmationDeleted: 'تم حذف التوكيد',
        affirmationSet: 'يتم عرض توكيدك المخصص الآن'
    },

    // Dialogs
    dialogs: {
        customAffirmations: 'توكيدات مخصصة',
        savedBackgrounds: 'خلفيات محفوظة',
        addCustomBackground: 'إضافة خلفية مخصصة',
        breathingExercise: 'تمرين التنفس',
        backupAndSync: 'النسخ الاحتياطي والمزامنة',
        cloudSyncStatus: 'حالة المزامنة السحابية',
        cloudSyncDescription: 'يتم مزامنة البيانات عبر جميع أجهزتك باستخدام Chrome Sync',
        localBackup: 'نسخة احتياطية محلية',
        localBackupDescription: 'إنشاء ملف احتياطي لإعداداتك والمفضلة والتأكيدات المخصصة',
        downloadBackup: 'تنزيل النسخة الاحتياطية',
        restoreFromBackup: 'استعادة من النسخة الاحتياطية',
        autoBackup: 'نسخ احتياطي تلقائي',
        autoBackupDescription: 'يتم نسخ بياناتك احتياطيًا تلقائيًا كل يوم',
        lastBackupCompleted: 'اكتمل آخر نسخ احتياطي بنجاح',
        lastBackup: 'آخر نسخة احتياطية',
        collections: {
            personal: 'شخصي',
            motivation: 'الدافع',
            gratitude: 'الامتنان',
            success: 'النجاح'
        },
        tabs: {
            personal: 'شخصي',
            motivation: 'الدافع',
            gratitude: 'الامتنان',
            success: 'النجاح'
        },
        useAffirmation: 'استخدام هذا التأكيد',
        deleteAffirmation: 'حذف التأكيد',
        typeYourAffirmation: 'اكتب تأكيدك...',
        add: 'إضافة'
    },

    // Premium Modal
    premiumModal: {
        title: 'فتح قفل ميزات Pro',
        favoriteAffirmationsTitle: 'التوكيدات المفضلة',
        favoriteAffirmationsDesc: 'احفظ توكيداتك المفضلة',
        shareTitle: 'مشاركة التوكيدات',
        shareDesc: 'شارك توكيداتك المفضلة',
        customAffirmationsTitle: 'توكيدات مخصصة',
        customAffirmationsDesc: 'أنشئ وأدر توكيداتك الخاصة',
        dailyRemindersTitle: 'التذكيرات اليومية',
        dailyRemindersDesc: 'احصل على إشعارات في الوقت المناسب لك',
        pricing: 'التسعير',
        monthly: 'شهري',
        pricePerMonth: '/شهر',
        chooseMonthly: 'اختر شهري',
        yearly: 'سنوي',
        pricePerYear: '/سنة',
        bestValue: 'أفضل قيمة',
        save: 'وفر 33%',
        allProFeatures: 'جميع ميزات Pro',
        prioritySupport: 'دعم ذو أولوية',
        cancelAnytime: 'إلغاء في أي وقت',
        twoMonthsFree: 'شهران مجانًا',
        chooseYearly: 'اختر سنوي',
        notSureYet: 'لست متأكدًا؟ جرب Pro مجانًا لمدة 7 أيام',
        startFreeTrial: 'ابدأ الإصدار التجريبي المجاني',
        closeModal: 'إغلاق النافذة'
    },

    // Help Dialog
    help: {
        title: 'مساعدة',
        gettingStarted: 'بدء الاستخدام',
        gettingStartedDesc: 'تظهر توكيدات جديدة في كل مرة تفتح فيها علامة تبويب جديدة. انقر على زر التحديث لرؤية واحدة جديدة.',
        favorites: 'المفضلة',
        favoritesDesc: 'انقر على أيقونة القلب لحفظ التوكيدات التي تحبها. يمكنك الوصول إليها في أي وقت من القائمة.',
        customAffirmations: 'توكيدات مخصصة',
        customAffirmationsDesc: 'إنشاء وإدارة توكيداتك الخاصة في قسم التوكيدات المخصصة.'
    },

    // Feedback Dialog
    feedback: {
        title: 'إرسال ملاحظات',
        intro: 'نحن نحب أن نسمع منك!',
        description: 'ملاحظاتك تساعدنا في تحسين Daily Affirmations للجميع.',
        selectFeedbackType: 'اختر نوع الملاحظات',
        suggestion: 'اقتراح',
        bugReport: 'تقرير خطأ',
        other: 'آخر',
        yourEmail: 'بريدك الإلكتروني (اختياري)',
        tellUs: 'أخبرنا بما تعتقده...',
        keepMeUpdated: 'أبقني على اطلاع بالميزات الجديدة',
        sendFeedback: 'إرسال الملاحظات',
        sending: 'جاري الإرسال...',
        thankYou: 'شكراً لك!',
        thankYouDesc: 'تم استلام ملاحظاتك. نحن نقدر مدخلاتك!',
        error: 'خطأ',
        errorDesc: 'فشل في إرسال الملاحظات. يرجى المحاولة مرة أخرى.'
    },

    // About Dialog
    about: {
        title: 'حول التوكيدات اليومية',
        version: 'النسخة',
        description: 'غير طريقة تفكيرك بتوكيدات إيجابية يومية.',
        dailyCuratedAffirmations: 'توكيدات يومية مفهرسة',
        saveFavorites: 'احفظ مفضلاتك',
        createCustom: 'إنشاء توكيدات مخصصة',
        cloudBackup: 'نسخ احتياطي ومزامنة سحابية',
        privacyPolicy: 'سياسة الخصوصية',
        termsOfService: 'شروط الخدمة',
        copyright: '© 2024 التوكيدات اليومية. جميع الحقوق محفوظة.',
        separator: '•'
    },

    // Menu
    menu: {
        myCollections: 'مجموعاتي',
        favoriteAffirmations: 'التوكيدات المفضلة',
        customAffirmations: 'توكيدات مخصصة',
        savedBackgrounds: 'خلفيات محفوظة',
        dailyReminders: 'تذكيرات يومية',
        themeSettings: 'إعدادات السمة',
        backup: 'النسخ الاحتياطي والمزامنة',
        help: 'مساعدة',
        feedback: 'ردود الفعل',
        about: 'حول'
    },

    // Accessibility
    accessibility: {
        openSettings: 'فتح لوحة الإعدادات',
        openMenu: 'فتح القائمة الرئيسية',
        toggleFocus: 'تبديل وضع التركيز',
        startBreathing: 'بدء تمرين التنفس',
        weatherInfo: 'معلومات الطقس',
        skipToContent: 'تخطي إلى المحتوى الرئيسي',
        closeDialog: 'إغلاق الحوار'
    },

    // Reminders
    reminders: {
        title: 'التذكيرات اليومية',
        enable: 'تفعيل التذكيرات اليومية',
        testNotification: 'اختبار الإشعار',
        repeatOn: 'تكرر في',
        reminderTimes: 'أوقات التذكير',
        addTime: 'إضافة وقت',
        customMessage: 'رسالة مخصصة',
        customMessagePlaceholder: 'وقت توكيدك اليومي!',
        mon: 'الإثنين',
        tue: 'الثلاثاء',
        wed: 'الأربعاء',
        thu: 'الخميس',
        fri: 'الجمعة',
        sat: 'السبت',
        sun: 'الأحد',
        blockedInSettings: 'تم حظر الإشعارات في الإعدادات. يرجى تفعيلها لتلقي التوكيدات اليومية.',
        openSystemSettings: 'فتح إعدادات النظام',
        notSupported: 'الإشعارات غير مدعومة في هذا المتصفح',
        needsPermission: 'يتطلب امتداد Chrome إذن الإشعارات',
        enableInSettings: 'يرجى تفعيل الإشعارات في إعدادات النظام',
        testNotificationTitle: 'اختبار الإشعار',
        testNotificationMessage: 'الإشعارات تعمل! ترقية إلى Pro للحصول على تذكيرات التوكيدات اليومية 🎉',
        testNotificationSent: 'تم إرسال اختبار الإشعار! تحقق من مركز الإشعارات.',
        settingsSaved: 'تم حفظ الإعدادات',
        settingsUpdated: 'تم تحديث إعدادات التذكير',
        settingsSavedFailed: 'فشل حفظ إعدادات التذكير'
    }
};

