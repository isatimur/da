/**
 * Hindi translations
 */

export default {
    // Common
    common: {
        start: 'शुरू',
        stop: 'रोकें',
        pause: 'रोकें',
        resume: 'जारी रखें',
        settings: 'सेटिंग्स',
        close: 'बंद करें',
        save: 'सहेजें',
        cancel: 'रद्द करें',
        ok: 'ठीक है',
        yes: 'हाँ',
        no: 'नहीं',
        loading: 'लोड हो रहा है...',
        error: 'त्रुटि',
        success: 'सफल',
        warning: 'चेतावनी',
        info: 'जानकारी',
        display: 'प्रदर्शन',
        showWeather: 'मौसम दिखाएं',
        showClock: 'घड़ी दिखाएं',
        returnToRandom: 'यादृच्छिक पृष्ठभूमि पर वापस जाएं',
        randomMode: 'यादृच्छिक मोड',
        fixedBackground: 'निश्चित पृष्ठभूमि',
        randomBackgrounds: 'यादृच्छिक पृष्ठभूमि',
        noSavedBackgrounds: 'अभी तक कोई पृष्ठभूमि सहेजी नहीं गई',
        saveFromUnsplash: 'Unsplash से पृष्ठभूमि सहेजें या अपनी कस्टम छवियाँ जोड़ें',
        currentBackground: 'वर्तमान',
        lastUsed: 'अंतिम उपयोग',
        useThisBackground: 'इस पृष्ठभूमि का उपयोग करें',
        setAsFixedBackground: 'निश्चित पृष्ठभूमि के रूप में सेट करें',
        removeFromSaved: 'सहेजी गई पृष्ठभूमि से हटाएं',
        customBackground: 'कस्टम पृष्ठभूमि',
        switching: 'स्विच कर रहे हैं...',
        uploading: 'अपलोड कर रहे हैं...',
        noAffirmationsInCollection: 'इस संग्रह में अभी तक कोई पुष्टिकरण नहीं है।',
        removeFromSaved: 'सहेजे से हटाएं',
        error: 'त्रुटि',
        failedToPerformAction: 'कार्रवाई करने में विफल'
    },

    // Breathing exercise
    breathing: {
        title: 'श्वास व्यायाम',
        ready: 'साँस लेने के लिए तैयार',
        clickStart: 'शुरू करने के लिए क्लिक करें',
        pattern: 'श्वास पैटर्न',
        duration: 'अवधि',
        minutes: 'मिनट',
        sessionComplete: 'सत्र पूरा!',
        sessionCompleteMessage: 'बढ़िया काम! आपने अपना श्वास सत्र पूरा कर लिया है।',
        completeMessage: '✓ पूर्ण',
        wellDoneMessage: 'बहुत बढ़िया! अपने फोकस की सराहना करने के लिए एक क्षण लें।',
        
        // Phases
        phases: {
            inhale: 'साँस लें',
            hold: 'रोकें',
            exhale: 'साँस छोड़ें',
            hold_after_exhale: 'विराम'
        },
        
        // Instructions
        instructions: {
            inhale: 'धीरे से नाक से साँस लें',
            hold: 'धीरे से साँस रोकें',
            exhale: 'धीरे से मुँह से साँस छोड़ें',
            hold_after_exhale: 'विश्राम करें और अगली साँस के लिए तैयार हों',
            followCircle: 'वृत्त का अनुसरण करें'
        },
        
        // Patterns
        patterns: {
            box: 'बॉक्स ब्रीदिंग',
            '4-7-8': '4-7-8 ब्रीदिंग',
            triangle: 'त्रिभुज श्वास',
            relaxing: 'आरामदायक श्वास',
            energizing: 'ऊर्जावान श्वास',
            mindful: 'सचेत श्वास'
        },
        
        // Pattern descriptions
        patternDescriptions: {
            box: 'Navy SEALs द्वारा तनाव प्रबंधन और फोकस के लिए उपयोग की जाने वाली एक संतुलित श्वास तकनीक।',
            '4-7-8': 'एक शांत करने वाली तकनीक जो चिंता कम करने और आराम को बढ़ावा देने में मदद करती है।',
            triangle: 'शुरुआती लोगों के लिए एक सरल, संतुलित श्वास पैटर्न।',
            relaxing: 'गहरी छूट और तनाव से राहत के लिए डिज़ाइन किया गया एक सौम्य पैटर्न।',
            energizing: 'सतर्कता और ऊर्जा को बढ़ावा देने के लिए एक तेज़, ऊर्जावान पैटर्न।',
            mindful: 'सचेत जागरूकता और वर्तमान क्षण में उपस्थिति पर केंद्रित एक सरल पैटर्न।'
        },
        
        // Benefits
        benefits: {
            box: ['तनाव कम करता है', 'फोकस बढ़ाता है', 'तंत्रिका तंत्र को संतुलित करता है'],
            '4-7-8': ['चिंता कम करता है', 'नींद को बढ़ावा देता है', 'तंत्रिका तंत्र को शांत करता है'],
            triangle: ['सीखना आसान', 'शांति को बढ़ावा देता है', 'शुरुआती लोगों के लिए अच्छा'],
            relaxing: ['गहरी छूट', 'तनाव से राहत', 'बेहतर नींद'],
            energizing: ['ऊर्जा बढ़ाता है', 'सतर्कता बढ़ाता है', 'तीव्र सक्रियता'],
            mindful: ['सचेतन', 'वर्तमान क्षण की जागरूकता', 'मानसिक स्पष्टता']
        },
        
        // Settings
        settings: {
            title: 'श्वास सेटिंग्स',
            defaultPattern: 'डिफ़ॉल्ट पैटर्न',
            defaultDuration: 'डिफ़ॉल्ट अवधि',
            autoStart: 'नए टैब पर स्वचालित शुरुआत',
            sound: 'ध्वनि',
            analytics: 'विश्लेषिकी दिखाएं',
            theme: 'श्वास थीम',
            comingSoon: 'सेटिंग्स पैनल जल्द आ रहा है!',
            patternChanged: 'श्वास पैटर्न बदल दिया गया',
            durationChanged: 'श्वास की अवधि बदल दी गई',
            startNewSession: 'नया सत्र शुरू करें'
        },
        
        // Statistics
        stats: {
            totalSessions: 'कुल सत्र',
            totalTime: 'कुल समय',
            currentStreak: 'वर्तमान शृंखला',
            longestStreak: 'सबसे लंबी शृंखला',
            averageSession: 'औसत सत्र',
            thisWeek: 'इस सप्ताह',
            thisMonth: 'इस महीने'
        },
        
        // Reports
        reports: {
            title: 'श्वास रिपोर्ट',
            phase: 'चरण',
            duration: 'अवधि',
            timestamp: 'समय'
        }
    },

    // Main app
    app: {
        title: 'नया टैब',
        weather: 'मौसम',
        affirmations: 'पुष्टिकरण',
        breathing: 'श्वास',
        settings: 'सेटिंग्स',
        premium: 'प्रीमियम',
        backup: 'बैकअप',
        restore: 'पुनर्स्थापित करें'
    },

    // Weather
    weather: {
        loading: 'मौसम लोड हो रहा है...',
        error: 'मौसम लोड करने में विफल',
        noData: 'मौसम डेटा उपलब्ध नहीं',
        feelsLike: 'लगता है',
        humidity: 'आर्द्रता',
        wind: 'हवा',
        pressure: 'दबाव',
        visibility: 'दृश्यता',
        uvIndex: 'UV सूचकांक'
    },

    // Affirmations
    affirmations: {
        loading: 'पुष्टिकरण लोड हो रहा है...',
        error: 'पुष्टिकरण लोड करने में विफल',
        noData: 'पुष्टिकरण उपलब्ध नहीं',
        refresh: 'रीफ्रेश',
        favorite: 'पसंदीदा',
        share: 'शेयर करें',
        copy: 'कॉपी',
        new: 'नया पुष्टिकरण',
        addToFavorites: 'पसंदीदा में जोड़ें',
        manageFavorites: 'पसंदीदा प्रबंधित करें'
    },

    // Settings
    settings: {
        title: 'सेटिंग्स',
        theme: 'थीम',
        language: 'भाषा',
        notifications: 'सूचनाएँ',
        privacy: 'गोपनीयता',
        about: 'के बारे में',
        version: 'संस्करण',
        developer: 'डेवलपर',
        backgroundTheme: 'पृष्ठभूमि थीम',
        cardStyle: 'कार्ड शैली',
        fontStyle: 'फ़ॉन्ट शैली',
        textColor: 'टेक्स्ट रंग',
        backup: 'बैकअप',
        resetToDefaults: 'डिफ़ॉल्ट रीसेट करें'
    },

    // Premium
    premium: {
        title: 'प्रीमियम सुविधाएँ',
        upgrade: 'प्रीमियम में अपग्रेड करें',
        features: 'प्रीमियम सुविधाएँ',
        trial: 'ट्रायल अवधि',
        subscribe: 'सदस्यता लें',
        manage: 'सदस्यता प्रबंधन',
        free: 'मुफ्त'
    },

    // Keyboard shortcuts
    shortcuts: {
        breathing: 'श्वास व्यायाम शुरू करें',
        weather: 'मौसम रीफ्रेश करें',
        affirmations: 'पुष्टिकरण रीफ्रेश करें',
        settings: 'सेटिंग्स खोलें'
    },

    // Time formats
    time: {
        now: 'अभी',
        minutesAgo: '{{count}} मिनट पहले',
        hoursAgo: '{{count}} घंटे पहले',
        daysAgo: '{{count}} दिन पहले',
        weeksAgo: '{{count}} सप्ताह पहले',
        monthsAgo: '{{count}} महीने पहले',
        yearsAgo: '{{count}} साल पहले'
    },

    // Errors
    errors: {
        network: 'नेटवर्क त्रुटि',
        permission: 'अपर्याप्त अनुमति',
        storage: 'संग्रहण त्रुटि',
        unknown: 'अज्ञात त्रुटि',
        retry: 'पुन: प्रयास करें'
    },

    // Notifications
    notifications: {
        themeUpdated: 'थीम अद्यतन',
        themeChanged: 'पृष्ठभूमि थीम {{theme}} में बदल दी गई है',
        settingsUpdated: 'सेटिंग्स अद्यतन',
        premiumRequired: 'प्रीमियम आवश्यक',
        error: 'त्रुटि',
        upgradeToPro: 'इस सुविधा का उपयोग करने के लिए Pro में अपग्रेड करें',
        backgroundSaved: 'पृष्ठभूमि सहेजी गई',
        affirmationCopied: 'पुष्टिकरण क्लिपबोर्ड पर कॉपी किया गया',
        favoritesAdded: 'पसंदीदा में जोड़ा गया',
        favoritesRemoved: 'पसंदीदा से हटा दिया गया',
        patternChanged: 'श्वास पैटर्न बदल दिया गया',
        durationChanged: 'श्वास की अवधि बदल दी गई',
        affirmationAdded: 'पुष्टिकरण जोड़ा गया',
        affirmationSaved: 'आपका पुष्टिकरण सहेजा गया है',
        affirmationDeleted: 'पुष्टिकरण हटा दिया गया',
        affirmationSet: 'आपका कस्टम पुष्टिकरण अब प्रदर्शित है'
    },

    // Dialogs
    dialogs: {
        customAffirmations: 'कस्टम पुष्टिकरण',
        savedBackgrounds: 'सहेजी गई पृष्ठभूमि',
        addCustomBackground: 'कस्टम पृष्ठभूमि जोड़ें',
        breathingExercise: 'श्वास व्यायाम',
        backupAndSync: 'बैकअप और सिंक',
        cloudSyncStatus: 'क्लाउड सिंक स्थिति',
        cloudSyncDescription: 'आपका डेटा Chrome Sync का उपयोग करके आपके सभी उपकरणों पर सिंक होता है',
        localBackup: 'स्थानीय बैकअप',
        localBackupDescription: 'अपनी सेटिंग्स, पसंद और कस्टम पुष्टिकरणों का बैकअप फ़ाइल बनाएं',
        downloadBackup: 'बैकअप डाउनलोड करें',
        restoreFromBackup: 'बैकअप से पुनर्स्थापित करें',
        autoBackup: 'स्वचालित बैकअप',
        autoBackupDescription: 'आपका डेटा हर दिन स्वचालित रूप से बैकअप किया जाता है',
        lastBackupCompleted: 'अंतिम बैकअप सफलतापूर्वक पूरा हुआ',
        lastBackup: 'अंतिम बैकअप',
        collections: {
            personal: 'व्यक्तिगत',
            motivation: 'प्रेरणा',
            gratitude: 'कृतज्ञता',
            success: 'सफलता'
        },
        tabs: {
            personal: 'व्यक्तिगत',
            motivation: 'प्रेरणा',
            gratitude: 'कृतज्ञता',
            success: 'सफलता'
        },
        useAffirmation: 'इस पुष्टिकरण का उपयोग करें',
        deleteAffirmation: 'पुष्टिकरण हटाएं',
        typeYourAffirmation: 'अपना पुष्टिकरण टाइप करें...',
        add: 'जोड़ें'
    },

    // Premium Modal
    premiumModal: {
        title: 'Pro सुविधाएँ अनलॉक करें',
        favoriteAffirmationsTitle: 'पसंदीदा पुष्टिकरण',
        favoriteAffirmationsDesc: 'अपने पसंदीदा पुष्टिकरण सेव करें',
        shareTitle: 'पुष्टिकरण साझा करें',
        shareDesc: 'अपने पसंदीदा पुष्टिकरण साझा करें',
        customAffirmationsTitle: 'कस्टम पुष्टिकरण',
        customAffirmationsDesc: 'अपने स्वयं के पुष्टिकरण बनाएं और प्रबंधित करें',
        dailyRemindersTitle: 'दैनिक अनुस्मारक',
        dailyRemindersDesc: 'अपने पसंदीदा समय पर अधिसूचित हों',
        pricing: 'मूल्य निर्धारण',
        monthly: 'मासिक',
        pricePerMonth: '/महीना',
        chooseMonthly: 'मासिक चुनें',
        yearly: 'वार्षिक',
        pricePerYear: '/वर्ष',
        bestValue: 'सर्वोत्तम मूल्य',
        save: '33% बचाएं',
        allProFeatures: 'सभी Pro सुविधाएँ',
        prioritySupport: 'प्राथमिकता समर्थन',
        cancelAnytime: 'किसी भी समय रद्द करें',
        twoMonthsFree: '2 महीने मुफ्त',
        chooseYearly: 'वार्षिक चुनें',
        notSureYet: 'अभी निश्चित नहीं? 7 दिनों के लिए मुफ्त Pro आज़माएं',
        startFreeTrial: 'मुफ्त परीक्षण शुरू करें',
        closeModal: 'विंडो बंद करें'
    },

    // Help Dialog
    help: {
        title: 'मदद',
        gettingStarted: 'शुरुआत करना',
        gettingStartedDesc: 'प्रत्येक बार जब आप नया टैब खोलते हैं तो नए पुष्टिकरण दिखाई देते हैं। नया देखने के लिए रीफ्रेश बटन पर क्लिक करें।',
        favorites: 'पसंदीदा',
        favoritesDesc: 'आपके पसंदीदा पुष्टिकरण सेव करने के लिए दिल आइकन पर क्लिक करें। मेनू से कभी भी उन तक पहुंचें।',
        customAffirmations: 'कस्टम पुष्टिकरण',
        customAffirmationsDesc: 'कस्टम पुष्टिकरण अनुभाग में अपने स्वयं के पुष्टिकरण बनाएं और प्रबंधित करें।'
    },

    // Feedback Dialog
    feedback: {
        title: 'प्रतिक्रिया भेजें',
        intro: 'हम आपसे सुनना पसंद करेंगे!',
        description: 'आपकी प्रतिक्रिया हमें सभी के लिए Daily Affirmations में सुधार करने में मदद करती है।',
        selectFeedbackType: 'प्रतिक्रिया प्रकार चुनें',
        suggestion: 'सुझाव',
        bugReport: 'बग रिपोर्ट',
        other: 'अन्य',
        yourEmail: 'आपका ईमेल (वैकल्पिक)',
        tellUs: 'हमें बताएं कि आप क्या सोचते हैं...',
        keepMeUpdated: 'मुझे नई सुविधाओं पर अपडेट रखें',
        sendFeedback: 'प्रतिक्रिया भेजें',
        sending: 'भेज रहे हैं...',
        thankYou: 'धन्यवाद!',
        thankYouDesc: 'आपकी प्रतिक्रिया प्राप्त हो गई है। हम आपके योगदान की सराहना करते हैं!',
        error: 'त्रुटि',
        errorDesc: 'प्रतिक्रिया भेजने में विफल। कृपया फिर से कोशिश करें।'
    },

    // About Dialog
    about: {
        title: 'Daily Affirmations के बारे में',
        version: 'संस्करण',
        description: 'दैनिक सकारात्मक पुष्टिकरणों से अपने मानसिकता को बदलें।',
        dailyCuratedAffirmations: 'दैनिक क्यूरेटेड पुष्टिकरण',
        saveFavorites: 'अपने पसंदीदा सेव करें',
        createCustom: 'कस्टम पुष्टिकरण बनाएं',
        cloudBackup: 'क्लाउड बैकअप और सिंक',
        privacyPolicy: 'गोपनीयता नीति',
        termsOfService: 'सेवा की शर्तें',
        copyright: '© 2024 Daily Affirmations. सभी अधिकार सुरक्षित।',
        separator: '•'
    },

    // Menu
    menu: {
        myCollections: 'मेरे संग्रह',
        favoriteAffirmations: 'पसंदीदा पुष्टिकरण',
        customAffirmations: 'कस्टम पुष्टिकरण',
        savedBackgrounds: 'सहेजी गई पृष्ठभूमि',
        dailyReminders: 'दैनिक अनुस्मारक',
        themeSettings: 'थीम सेटिंग्स',
        backup: 'बैकअप और सिंक',
        help: 'मदद',
        feedback: 'प्रतिपुष्टि',
        about: 'के बारे में'
    },

    // Accessibility
    accessibility: {
        openSettings: 'सेटिंग्स पैनल खोलें',
        openMenu: 'मुख्य मेनू खोलें',
        toggleFocus: 'फोकस मोड टॉगल करें',
        startBreathing: 'श्वास व्यायाम शुरू करें',
        weatherInfo: 'मौसम जानकारी',
        skipToContent: 'मुख्य सामग्री पर जाएं',
        closeDialog: 'संवाद बंद करें'
    },

    // Reminders
    reminders: {
        title: 'दैनिक अनुस्मारक',
        enable: 'दैनिक अनुस्मारक सक्षम करें',
        testNotification: 'अधिसूचना परीक्षण',
        repeatOn: 'दोहराएं',
        reminderTimes: 'अनुस्मारक समय',
        addTime: 'समय जोड़ें',
        customMessage: 'कस्टम संदेश',
        customMessagePlaceholder: 'अपने दैनिक पुष्टिकरण का समय!',
        mon: 'सोम',
        tue: 'मंगल',
        wed: 'बुध',
        thu: 'गुरु',
        fri: 'शुक्र',
        sat: 'शनि',
        sun: 'रवि',
        blockedInSettings: 'सिस्टम सेटिंग्स में अधिसूचनाएं अवरुद्ध हैं। कृपया दैनिक पुष्टिकरण प्राप्त करने के लिए उन्हें सक्षम करें।',
        openSystemSettings: 'सिस्टम सेटिंग्स खोलें',
        notSupported: 'इस ब्राउज़र में अधिसूचनाएं समर्थित नहीं हैं',
        needsPermission: 'Chrome एक्सटेंशन को अधिसूचना अनुमति की आवश्यकता है',
        enableInSettings: 'कृपया सिस्टम सेटिंग्स में अधिसूचनाएं सक्षम करें',
        testNotificationTitle: 'अधिसूचना परीक्षण',
        testNotificationMessage: 'अधिसूचनाएं काम कर रही हैं! दैनिक पुष्टिकरण अनुस्मारक प्राप्त करने के लिए Pro में अपग्रेड करें 🎉',
        testNotificationSent: 'परीक्षण अधिसूचना भेजी गई! अधिसूचना केंद्र जांचें।',
        settingsSaved: 'सेटिंग्स सहेजे गए',
        settingsUpdated: 'अनुस्मारक सेटिंग्स अपडेट की गईं',
        settingsSavedFailed: 'अनुस्मारक सेटिंग्स सहेजने में विफल'
    }
};

